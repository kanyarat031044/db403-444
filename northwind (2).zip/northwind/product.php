<?php
session_start();
include 'db_connect.php';
?>
<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta http-equiv="X-UA-Compatible" content="IE=edge">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Northwind - Products</title>
  <link rel="stylesheet" href="css/style.css">
</head>
<body>
<?php
include 'header.php'; 
$sql = 'select CategoryName from categories where CategoryID=?';
$stmt = $conn->prepare($sql);
$stmt->bind_param('i', $_GET['category']);
try {
  $stmt->execute();
  $result = $stmt->get_result();
  $row = $result->fetch_assoc();
}
catch(Exception $e) {
  echo "Error: {$e->getMessage()}";
}
$stmt->close();
?>
  <h1 class="title">Product of <?=$row['CategoryName']?></h1>
  <div id="categories">
    <table id="product">
      <thead>
        <tr>
          <th>Product Name</th>
          <th>Unit Price</th>
        </tr>
      </thead>
      <tbody>

      </tbody>
    </table>
    <div id="summary">

      <h1 class="title">Cart</h1>
      <table id="cart">
        <thead>
          <tr>
            <th>Product Name</th>
            <th>Units</th>
          </tr>
        </thead>
        <tbody id="cart_details">

        </tbody>
      </table>

    </div>
    <form action="api/payment.php" method="post" enctype="multipart/form-data">
      Select image to upload:
      <input type="file" name="slip">
      <input type="submit" value="Upload Image" name="submit">
    </form>
    <script>
    let cart_details = document.querySelector('#cart_details');
    for(let cat of document.querySelectorAll('.product')) {
      cat.addEventListener('click', function() {

      });
    }
  </script>
</body>
</html>