function signin() {
  location.href="signin.php";
}

function signout() {
  location.href="signout.php";
}